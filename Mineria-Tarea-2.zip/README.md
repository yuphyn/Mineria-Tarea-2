# Mineria-Tarea-2
Tarea 2 de minería de datos, sistema de recomendaciones

### La data se encuentra en el sigueinte link
https://grouplens.org/datasets/movielens/10m/
